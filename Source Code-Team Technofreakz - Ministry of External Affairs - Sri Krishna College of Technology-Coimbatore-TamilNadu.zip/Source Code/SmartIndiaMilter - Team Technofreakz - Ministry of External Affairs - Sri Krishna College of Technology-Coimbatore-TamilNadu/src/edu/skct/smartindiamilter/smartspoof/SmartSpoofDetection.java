package edu.skct.smartindiamilter.smartspoof;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.lang.model.element.Element;

import edu.skct.smartindiamilter.model.Constants;
import edu.skct.smartindiamilter.model.FromEmailAddressModel;
import edu.skct.smartindiamilter.model.ReceivedFromModel;
import edu.skct.smartindiamilter.model.ReturnPathModel;
import edu.skct.smartinidamilter.dkim.AlgorithmDkimVerification;
import edu.skct.smartinidamilter.spf.AlgorithmSpfVerification;
import edu.skct.smartinidamilter.utils.SmartIndiaMilterUtils;

public class SmartSpoofDetection {

	private FromEmailAddressModel fromEmailAddressModel;
	private List<ReceivedFromModel> receivedFromModels;
	private ReturnPathModel returnPathModel;

	public Map<String, Boolean> isSpoofed(Map<String, String> headers, InputStream messageInputStream) {
		init(headers);
		Map<String, Boolean> resultMap = new LinkedHashMap<String, Boolean>();
		
		boolean returnPathMatch = isReturnPathDomainMatch();
		resultMap.put("Return Path Domain Match", returnPathMatch);
		if (!returnPathMatch)
			return resultMap;
		
		boolean domainMatch = isFromDomainMatch();
		resultMap.put("Received Chain Domain Match", domainMatch);
		if (!domainMatch)
			return resultMap;
		
		boolean reverseDnsMatch = isReverseDnsMatch();
		resultMap.put("Reverse DNS Match", reverseDnsMatch);
		if (!reverseDnsMatch)
			return resultMap;
		
		boolean dmarcCheck = isSPFVerified() && isDKIMVerified();
		resultMap.put("DMARC Check", dmarcCheck);
		return resultMap;
	}

	private void init(Map<String, String> headers) {
		SmartIndiaMilterUtils smartIndiaMilterUtils = new SmartIndiaMilterUtils();
		if (headers.containsKey(Constants.HEADER_FROM))
			this.fromEmailAddressModel = smartIndiaMilterUtils.parseFromEmail(headers.get(Constants.HEADER_FROM));
		if (headers.containsKey(Constants.HEADER_RECEIVED))
			this.receivedFromModels = smartIndiaMilterUtils.parseReceivedFields(headers.get(Constants.HEADER_RECEIVED));
		if (headers.containsKey(Constants.HEADER_RETURN_PATH))
			this.returnPathModel = smartIndiaMilterUtils.parseReturnPath(headers.get(Constants.HEADER_RETURN_PATH));
		if (headers.containsKey(Constants.HEADER_REPLY_TO))
			this.returnPathModel = smartIndiaMilterUtils.parseReturnPath(headers.get(Constants.HEADER_REPLY_TO));
	}

	private boolean isSPFVerified() {
		if (null == this.receivedFromModels.get(0).getReceivedIpAddress()
				|| this.receivedFromModels.get(0).getReceivedIpAddress().trim().isEmpty()
				|| null == this.fromEmailAddressModel.getFromEmail()
				|| this.fromEmailAddressModel.getFromEmail().trim().isEmpty()
				|| null == this.fromEmailAddressModel.getFromDomain()
				|| this.fromEmailAddressModel.getFromDomain().trim().isEmpty())
			return false;
		else {
			AlgorithmSpfVerification spfVerification = new AlgorithmSpfVerification();
			return spfVerification.verifySPF(this.receivedFromModels.get(0).getReceivedIpAddress(),
					this.fromEmailAddressModel.getFromEmail(), this.fromEmailAddressModel.getFromDomain());
		}
	}

	private boolean isDKIMVerified(InputStream inputStream) {
		AlgorithmDkimVerification algorithmDkimVerification = new AlgorithmDkimVerification();
		return algorithmDkimVerification.verifyDkim(inputStream);

	}
	
	private boolean isReturnPathDomainMatch() {
		if (null == returnPathModel || null == this.returnPathModel.getReturnPathDomain()
				|| this.returnPathModel.getReturnPathDomain().trim().isEmpty())
			return true;
		else if (null == this.fromEmailAddressModel.getFromDomain()
				|| this.fromEmailAddressModel.getFromDomain().trim().isEmpty())
			return false;
		else {
			return (this.returnPathModel.getReturnPathDomain().trim()
					.equals(this.fromEmailAddressModel.getFromDomain().trim())) ? true : false;
		}
	}

	private boolean isDKIMVerified() {
		AlgorithmDkimVerification algorithmDkimVerification = new AlgorithmDkimVerification();
		return algorithmDkimVerification.verifyDkim();

	}
	
	private boolean isFromDomainMatch() {
		if (null == this.receivedFromModels.get(0).getReceivedServer()
				|| this.receivedFromModels.get(0).getReceivedServer().trim().isEmpty()
				|| null == this.fromEmailAddressModel.getFromDomain()
				|| this.fromEmailAddressModel.getFromDomain().trim().isEmpty())
			return false;
		else {
			return (this.receivedFromModels.get(0).getReceivedServer().trim()
					.endsWith(this.fromEmailAddressModel.getFromDomain().trim())) ? true : false;
		}
	}

	private boolean isReverseDnsMatch() {
		if (isReturnPathDomainMatch()) {
			if (null == this.receivedFromModels.get(0).getReceivedServer()
					|| this.receivedFromModels.get(0).getReceivedServer().trim().isEmpty()
					|| null == this.receivedFromModels.get(0).getReverseDns()
					|| this.receivedFromModels.get(0).getReverseDns().trim().isEmpty())
				return false;
			else {
				return (this.receivedFromModels.get(0).getReceivedServer().trim()
						.equals(this.receivedFromModels.get(0).getReverseDns().trim())) ? true : false;
			}
		}
		else
		{
			return false;
		}
	}

}
