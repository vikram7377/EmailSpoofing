package edu.skct.smartindiamilter.mailet;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.mail.Header;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.mailet.GenericMailet;
import org.apache.mailet.Mail;

import edu.skct.smartindiamilter.model.Constants;
import edu.skct.smartindiamilter.model.FromEmailAddressModel;
import edu.skct.smartindiamilter.smartspoof.SmartSpoofDetection;
import edu.skct.smartinidamilter.praserFactory.Parser;
import edu.skct.smartinidamilter.praserFactory.ReadFromMimeMessageParser;
import edu.skct.smartinidamilter.utils.SmartIndiaMilterUtils;

public class SmartMailet extends GenericMailet {

	private String adminMails;
	
	private String alertMailId;

	public String getAdminMails() {
		return adminMails;
	}

	public void setAdminMails(String adminMails) {
		this.adminMails = adminMails;
	}
	
	public String getAlertMailId() {
		return alertMailId;
	}

	public void setAlertMailId(String alertMailId) {
		this.alertMailId = alertMailId;
	}

	public void init() throws MessagingException {
		adminMails = getInitParameter("adminMails");
		alertMailId = getInitParameter("alertMailId");
		log("Admin Mails = " + adminMails);
		log("Alert Mail ID = " + alertMailId);
	}

	@Override
	public void service(Mail arg0) throws MessagingException {

		Set<String> adminMailsParsed = new HashSet<String>();
		if (null != adminMails && !adminMails.trim().isEmpty())
			if (adminMails.contains(",")) {
				String[] mails = adminMails.split(",");
				for (String mail : mails)
					adminMailsParsed.add(mail.trim());
			} else {
				adminMailsParsed.add(adminMails.trim());
			}

		MimeMessage mimeMessage = arg0.getMessage();
		Parser parser = new ReadFromMimeMessageParser();
		SmartIndiaMilterUtils smartIndiaMilterUtils = new SmartIndiaMilterUtils();
		SmartSpoofDetection smartSpoofDetection = new SmartSpoofDetection();
		// Inputs
		Map<String, String> resultsMap = parser.parseInput(mimeMessage);
		log("Mails = "+adminMailsParsed.toString());
		log("From Address = "+resultsMap.get(Constants.HEADER_FROM));
		if (!adminMailsParsed.contains(resultsMap.get(Constants.HEADER_FROM).trim())) {
			String spitString = "";
			try {
				mimeMessage.getAllHeaderLines();
				for (@SuppressWarnings("unchecked")
				Enumeration<Header> e = mimeMessage.getAllHeaders(); e.hasMoreElements();) {
					Header h = e.nextElement();
					spitString += h.getName() + ": ";
					spitString += h.getValue() + "\r\n";
				}
				log(spitString);
			} catch (MessagingException e1) {
				log("Error", e1);
			}

			InputStream inputStream = smartIndiaMilterUtils.getInputSteam(mimeMessage);
			Map<String, Boolean> results = smartSpoofDetection.isSpoofed(resultsMap, inputStream);
			boolean isSpoofed = false;

			for (Map.Entry<String, Boolean> entry : results.entrySet()) {
				if (entry.getValue() == false)
					isSpoofed = true;
			}

			if (isSpoofed) {
				String mail_body= "<h3 style=\"color:red\">Red Alert</h3><br /><i>A message was spoofed and attempted to be sent to the mail <b>\""+resultsMap.get(Constants.HEADER_TO)+"\"</b><br />"
						+ "<br /><b>Tests Failed are as follows:</b> <br />";
				mail_body+="<table border=\"1\"><tr><th>Check</th><th>Result</th></tr>";
				for (Map.Entry<String, Boolean> entry : results.entrySet())
				{
					log(entry.getKey() + " " + ((false == entry.getValue()) ? "failed" : "passed"));
					mail_body+="<tr><td>"+entry.getKey() + "</td><td>" + ((false == entry.getValue()) ? "<b><span style=\"color:red\">FAIL</span></b>" : "<b><span style=\"color:green\">PASS</span></b></td></tr>");
				}
				mail_body+="</table><br /> <br />";
				mail_body +="----------------------RAW Message for Futher Examining--------------------------------<br />";
				try {
					mail_body += "<table border=\"1\">"
							+ "<tr><th>MIME Header</th><th>MIME Content</th></tr>";
					mimeMessage.getAllHeaderLines();
					for (@SuppressWarnings("unchecked")
					Enumeration<Header> e = mimeMessage.getAllHeaders(); e.hasMoreElements();) {
						Header h = e.nextElement();
						mail_body += "<tr><td>"+h.getName()+"</td><td>"+h.getValue()+"</td></tr>";
					}
					mail_body+="</table>";
					log(spitString);
				} catch (MessagingException e1) {
					mail_body += "<b>Could Not Retrieve the MIME Message due to an internal server error </b>";
					log("Error", e1);
				}
				
				mail_body+= "<br /> <br /><i>Anti-Spoof Filter <b>(Smart India Milter) developed by Indians for the New India</b> by team TecchnoFreakz, Sri Krishna College of Technology, Coimbatore, Tamil Nadu</i>";
				arg0.setState(Mail.GHOST);
				smartIndiaMilterUtils.sendMail(adminMails, alertMailId, mail_body);
			}
		}
	}

	public String getMailetInfo() {
		return "SmartIndia Hackathon Spoof Detection Mailet";
	}

}