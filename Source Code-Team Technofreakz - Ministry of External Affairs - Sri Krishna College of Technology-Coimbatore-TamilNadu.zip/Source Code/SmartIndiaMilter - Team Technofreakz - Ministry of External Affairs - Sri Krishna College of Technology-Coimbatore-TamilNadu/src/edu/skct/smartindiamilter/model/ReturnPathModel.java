package edu.skct.smartindiamilter.model;

public class ReturnPathModel {
	private String returnPathEmail;
	private String returnPathDomain;
	
	public String getReturnPathEmail() {
		return returnPathEmail;
	}
	public void setReturnPathEmail(String returnPathEmail) {
		this.returnPathEmail = returnPathEmail;
	}
	public String getReturnPathDomain() {
		return returnPathDomain;
	}
	public void setReturnPathDomain(String returnPathDomain) {
		this.returnPathDomain = returnPathDomain;
	}
	@Override
	public String toString() {
		return "ReturnPathModel [returnPathEmail=" + returnPathEmail + ", returnPathDomain=" + returnPathDomain + "]";
	}
	
	
}
