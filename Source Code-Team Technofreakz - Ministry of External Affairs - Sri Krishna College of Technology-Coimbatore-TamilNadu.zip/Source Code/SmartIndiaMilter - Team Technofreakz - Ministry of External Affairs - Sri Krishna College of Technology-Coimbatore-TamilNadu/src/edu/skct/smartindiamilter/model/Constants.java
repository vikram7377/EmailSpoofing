package edu.skct.smartindiamilter.model;

public class Constants {
	
	public static final String RESULT_FAIL = "FAIL";
	public static final String HEADER_RECEIVED = "Received";
	public static final String HEADER_FROM = "From";
	public static final String HEADER_RETURN_PATH = "Return-Path";
	public static final String HEADER_REPLY_TO = "Reply-To";
	public static final String HEADER_TO = "To";
	public static final String NEWLINE = "\r\n";
	public static final String SPF_PASS = "pass";
	public static final String username = "vikram@effeye.com";
	public static final String password = "P@ssword1";
	
}
