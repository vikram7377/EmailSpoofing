package edu.skct.smartinidamilter.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import javax.mail.Header;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import edu.skct.smartindiamilter.model.Constants;
import edu.skct.smartindiamilter.model.FromEmailAddressModel;
import edu.skct.smartindiamilter.model.ReceivedFromModel;
import edu.skct.smartindiamilter.model.ReturnPathModel;

public class SmartIndiaMilterUtils {
	private static Logger logger = Logger.getLogger(SmartIndiaMilterUtils.class);

	public String reverseDnsLookup(String ipAddress) {
		try {
			InetAddress inetAddress = InetAddress.getByName(ipAddress);
			String canonicalName = inetAddress.getCanonicalHostName();
			return (canonicalName.equals(ipAddress)) ? Constants.RESULT_FAIL : canonicalName;
		} catch (UnknownHostException e) {
			logger.warn(e);
			return null;
		}
	}

	public InputStream getInputSteam(MimeMessage mimeMessage) {
		try {
			mimeMessage.getAllHeaderLines();
			String spitString = "";
			for (@SuppressWarnings("unchecked")
			Enumeration<Header> e = mimeMessage.getAllHeaders(); e.hasMoreElements();) {
				Header h = e.nextElement();
				spitString += h.getName() + ": ";
				spitString += h.getValue() + "\r\n";
			}
			return new ByteArrayInputStream(spitString.getBytes());
		} catch (MessagingException e1) {
			logger.warn("Error", e1);
			return null;
		}
	}

	public List<ReceivedFromModel> parseReceivedFields(String receivedContent) {
		String[] lines = receivedContent.split(Constants.NEWLINE);
		List<ReceivedFromModel> granular = new ArrayList<>();
		for (String line : lines) {
			if (line.startsWith("from")) {
				ReceivedFromModel data = new ReceivedFromModel();
				if (line.contains("(") && line.contains(")")) {
					String receivedServer = line.substring(line.indexOf("from ") + 5, line.indexOf("("));
					data.setReceivedServer(receivedServer);

					String receivedIpAddress = line.substring(line.lastIndexOf("(") + 1, line.lastIndexOf(")"));
					if (receivedIpAddress.contains("[") && receivedIpAddress.contains("]"))
						receivedIpAddress = receivedIpAddress.substring(receivedIpAddress.indexOf("[") + 1,
								receivedIpAddress.indexOf("]"));
					data.setReceivedIpAddress(receivedIpAddress);
					data.setReverseDns(reverseDnsLookup(receivedIpAddress));
					granular.add(data);
				} else {
					String receivedServer = line.substring(line.indexOf("from ") + 5);
					data.setReceivedServer(receivedServer.trim());
					data.setReceivedIpAddress("");
					data.setReverseDns("");
				}
			}
		}
		return granular;
	}

	public void sendMail(String fromAddress, String toAddress, String message_body) {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "false");
		props.put("mail.smtp.host", "effeye.com");
		props.put("mail.smtp.port", "25");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(Constants.username, Constants.password);
			}
		});

		try {

			if (null != toAddress && !toAddress.isEmpty()) {
				String[] addresses = toAddress.split(",");
				Message message = new MimeMessage(session);
				message.setFrom(new InternetAddress(fromAddress));
				for(int i=0;i<addresses.length;i++)
				{
					if(i==0)
						message.setRecipients(javax.mail.Message.RecipientType.TO, InternetAddress.parse(addresses[i]));
					else
						message.addRecipients(javax.mail.Message.RecipientType.TO, InternetAddress.parse(addresses[i]));
				}
				message.setSubject("TechnoFreakz : Forensic Analysis Helper Mail");
				message.setContent(message_body,"text/html");
				Transport.send(message);
			}
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

	public ReturnPathModel parseReturnPath(String returnPath) {
		ReturnPathModel returnPathModel = new ReturnPathModel();
		if (returnPath.contains("<") && returnPath.contains(">"))
			returnPath = returnPath.replace("<", "").replace(">", "");
		if (returnPath.contains("@")) {
			String[] splitEmail = returnPath.split("@");
			if (splitEmail.length == 2) {
				returnPathModel.setReturnPathDomain(splitEmail[1]);
				returnPathModel.setReturnPathEmail(returnPath);
			}
		} else {
			returnPathModel.setReturnPathEmail(returnPath);
			returnPathModel.setReturnPathDomain("");
		}
		return returnPathModel;
	}

	public FromEmailAddressModel parseFromEmail(String fromEmail) {
		FromEmailAddressModel model = new FromEmailAddressModel();
		if (fromEmail.contains("<") && fromEmail.contains(">")) {
			model.setFromName(fromEmail.substring(0, fromEmail.indexOf("<")));
			model.setFromEmail(fromEmail.substring(fromEmail.indexOf("<") + 1, fromEmail.indexOf(">")));
			model.setFromDomain(model.getFromEmail().split("@")[1]);
			return model;
		} else {
			model.setFromName(fromEmail);
			model.setFromEmail(fromEmail);
			model.setFromDomain(model.getFromEmail().split("@")[1]);
			return model;
		}
	}

	public InputStream createInputStream(String filePath) {
		File file = new File(String.valueOf(filePath));
		BufferedReader bufferedReader;
		String content = "";
		String line = "";
		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			while (null != (line = bufferedReader.readLine())) {
				content += line + Constants.NEWLINE;
			}
		} catch (FileNotFoundException e1) {
			logger.warn(e1);
		} catch (IOException e) {
			logger.warn(e);
		}

		InputStream inputStream = new ByteArrayInputStream(content.getBytes());
		return inputStream;
	}

	public boolean parseSPFResult(String result) {
		return (result.trim().equals(Constants.SPF_PASS)) ? true : false;
	}

}
