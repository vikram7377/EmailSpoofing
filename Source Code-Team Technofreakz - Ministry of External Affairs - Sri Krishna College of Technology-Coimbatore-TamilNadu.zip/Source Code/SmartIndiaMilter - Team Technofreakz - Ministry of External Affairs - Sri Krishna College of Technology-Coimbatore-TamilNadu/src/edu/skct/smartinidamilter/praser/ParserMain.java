/**
 * 
 */
package edu.skct.smartinidamilter.praser;

import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import edu.skct.smartindiamilter.model.Constants;
import edu.skct.smartindiamilter.smartspoof.SmartSpoofDetection;
import edu.skct.smartinidamilter.dkim.AlgorithmDkimVerification;
import edu.skct.smartinidamilter.praserFactory.Parser;
import edu.skct.smartinidamilter.praserFactory.ReadFromFileParser;
import edu.skct.smartinidamilter.utils.SmartIndiaMilterUtils;

/**
 * @author saseea
 *
 */
public class ParserMain {

	
	public void dump()
	{
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*Parser parser = new ReadFromFileParser();
		try {
			String file = "src/sample4.txt";
			SmartSpoofDetection spoofDetection = new SmartSpoofDetection();
			//To parse the MIME Message
			SmartIndiaMilterUtils smartIndiaMilterUtils = new SmartIndiaMilterUtils();
			InputStream messageInputStream = smartIndiaMilterUtils.createInputStream(file);
			Map<String, String> resultMap = parser.parseInput(messageInputStream);
			System.out.println(spoofDetection.isSpoofed(resultMap,messageInputStream));
			
				
			
			
			
		} catch (MessagingException e) {
			e.printStackTrace();
		}
*/
		
		/*
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "false");
		props.put("mail.smtp.host", "effeye.com");
		props.put("mail.smtp.port", "25");
		
		Session session = Session.getInstance(props,
				  new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(Constants.username, Constants.password);
					}
				  });

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("vikram@effeye.com"));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse("ats0stv@gmail.com"));
			message.setSubject("Testing Subject");
			message.setContent("<b>Dear Mail Crawler</b>,<br />"
				+ "\n\n<span style=\"color:red\"> No spam to my email, please!</span>","text/html");

			Transport.send(message);

			System.out.println("Done");

		} catch (MessagingException e) {
			e.printStackTrace();
		}
*/
	}
	
	
	

}
